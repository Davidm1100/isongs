DROP TABLE IF EXISTS `Songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Songs` (
  `Song_ID` varchar(20) NOT NULL,
  `Song_name` text NOT NULL,
  `Artist_ID` varchar(20) NOT NULL,
  `Release_date` text NOT NULL,
  `Genre` text NOT NULL,
  `Price` decimal(2,2) NOT NULL,
  PRIMARY KEY (`Song_ID`),
  KEY `Artist_ID` (`Artist_ID`),
  KEY `Artist_ID_2` (`Artist_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `Songs` (`Song_ID`, `Song_name`, `Artist_ID`, `Release_date`, `Genre`, `Price`) VALUES ('S1','Right Here Right Now','A1','2012-07-21','Dance',0.99),('S10','Falafel','A4','2016-09-08','Alternative',0.99),('S11','It Runs Through Me','A4','2016-09-09','Alternative',0.99),('S12','Water Baby','A4','2016-09-10','Alternative',0.99),('S13','Crazy Dream (fear Loyle Carner)','A4','2016-09-11','Alternative',0.99),('S14','Liquid Spirit','A5','2006-04-23','Jazz',0.99),('S15','Water Under Bridges ','A5','2006-04-24','Jazz',0.99),('S16','Hey Laura','A5','2006-04-25','Jazz',0.99),('S17','Brown Grass','A5','2015-02-17','Jazz',0.99),('S18','White Man','A6','2015-02-18','R&B',0.79),('S19','Tadow','A6','2015-02-19','R&B',0.79),('S2','Rockafella Skank','A1','2012-07-21','Dance',0.99),('S20','Melanin Man','A6','2015-02-20','R&B',0.99),('S21','Dean Town','A7','2015-02-21','R&B',0.99),('S22','Back Pocket','A7','2015-02-22','R&B',0.99),('S23','Welcome to Vulf Records','A7','2015-02-23','R&B',0.99),('S24','Animal Spirits','A7','2015-02-24','R&B',0.99),('S25','Conscious Club','A7','2015-02-25','R&B',0.99),('S26','Wait For The Moment','A7','2015-02-26','R&B',0.99),('S27','Bring Us The Bright','A8','2013-10-19','Jazz',0.79),('S28','Loose Screws','A8','2013-10-20','Jazz',0.79),('S29','Making A Circle','A8','2013-10-21','Jazz',0.79),('S3','Praise You','A1','2012-07-21','Dance',0.99),('S30','Phoebus','A8','2013-10-22','Jazz',0.79),('S31','Strange Dream','A8','2013-10-23','Jazz',0.79),('S32','And Soon We\'ll Be One','A8','2013-10-24','Jazz',0.79),('S33','Cant\'t Stop','A9','1997-08-12','Alternative',0.79),('S34','Under The Bridge','A9','1997-08-13','Alternative',0.79),('S35','Higher Ground','A9','1997-08-14','Alternative',0.79),('S36','Road Trippin\'','A9','1997-08-15','Alternative',0.79),('S37','Parallel Universe','A9','1997-08-16','Alternative',0.79),('S38','Californication','A9','1997-08-17','Alternative',0.79),('S39','Scar Tissue','A9','1997-08-18','Alternative',0.79),('S4','Quality Control','A2','2007-05-14','Hip-Hop',0.99),('S40','Dani California','A9','1997-08-19','Alternative',0.79),('S41','Get On Top','A9','1997-08-20','Alternative',0.79),('S42','Right On Time','A9','1997-08-21','Alternative',0.79),('S43','Tell Me Baby','A9','1997-08-22','Alternative',0.79),('S5','Contribution','A2','2007-05-14','Hip-Hop',0.99),('S6','The Game','A2','2007-05-14','Hip-Hop',0.99),('S7','Write It On Your Skin','A3','2011-04-03','Pop',0.99),('S8','Brick By Brick','A3','2011-04-03','Pop',0.99),('S9','Soon','A3','2011-04-03','Pop',0.99),('Song_ID','Song_Name','Artist_ID','Release_Date','Genre',0.00);
