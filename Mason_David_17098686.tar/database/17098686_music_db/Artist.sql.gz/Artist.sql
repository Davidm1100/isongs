DROP TABLE IF EXISTS `Artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Artist` (
  `Artist_ID` varchar(20) NOT NULL,
  `Artist_name` text NOT NULL,
  `Nationality` text NOT NULL,
  `Label` text NOT NULL,
  KEY `Artist_ID` (`Artist_ID`),
  KEY `Artist_ID_2` (`Artist_ID`),
  KEY `Artist_ID_3` (`Artist_ID`),
  KEY `Artist_ID_4` (`Artist_ID`),
  KEY `Artist_ID_5` (`Artist_ID`),
  KEY `Artist_ID_6` (`Artist_ID`),
  KEY `Artist_ID_7` (`Artist_ID`),
  CONSTRAINT `Artist_ibfk_1` FOREIGN KEY (`Artist_ID`) REFERENCES `Songs` (`Artist_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `Artist` (`Artist_ID`, `Artist_name`, `Nationality`, `Label`) VALUES ('A1','FatBoy Slim','UK','Skint Records'),('A2','Jurassic 5','US','Interscope Records'),('A3','Newton Faulkner','UK','Song'),('A4','Tom Misch','UK','Kobalt Label Services'),('A5','Gregory Porter','US','Blue Note Records'),('A6','Masego','US','ICM'),('A7','Vulfpeck','US','Vulf Records'),('A8','Snarky Puppy','US','Ropeadope Records'),('A9','Red Hot Chilli Peppers','US','Warner Music Group');
