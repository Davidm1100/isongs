DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `Customer_ID` int(11) NOT NULL AUTO_INCREMENT,
  `First_name` varchar(40) DEFAULT NULL,
  `Last_name` varchar(40) DEFAULT NULL,
  `Email` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`Customer_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `customers` (`Customer_ID`, `First_name`, `Last_name`, `Email`) VALUES (1,'Dave','Mason','dave@gmail.com'),(2,'John','Deer','John@deer.com'),(3,'Tim','Allen','Tim@allen.com'),(4,'Jim','Bines','Jim@bines.co.uk'),(5,'Robert','Johnson','Rob.j@gmail.com'),(6,'Jamie','Phillips','j.phillips@outlook.com'),(7,'Edward','Snowden','eddysnow@googlemail.com'),(8,'John','Jones','johnjones@googlemail.com'),(9,'Robert','West','robwest@gmail.com'),(10,'Jim','Goody','jgoody@gmail.com');
